async function upload() {
    const file = document.getElementById('fileInput').files[0];
    const formData = new FormData();
    formData.append('file', file);
    const rsaKey = prompt("Paste RSA Public Key:");
    formData.append('rsa_pub_key', rsaKey);

    const res = await fetch('http://localhost:5000/upload', {
        method: 'POST',
        body: formData
    });

    const data = await res.json();
    alert("File Uploaded. Encrypted AES key: " + data.aes_key);
}