from flask import Flask, request, jsonify
import base64
from crypto_utils import *
from firebase_config import upload_to_firebase

app = Flask(__name__)

@app.route('/upload', methods=['POST'])
def upload():
    file = request.files['file']
    rsa_pub_key = request.form['rsa_pub_key']

    aes_key = get_random_bytes(32)
    encrypted_data = encrypt_file(file.read(), aes_key)

    encrypted_aes_key = encrypt_aes_key(aes_key, rsa_pub_key)

    filename = file.filename + '.enc'
    upload_to_firebase(filename, encrypted_data['ciphertext'])

    return jsonify({
        'message': 'Upload successful',
        'file': filename,
        'aes_key': base64.b64encode(encrypted_aes_key).decode()
    })

if __name__ == '__main__':
    app.run(debug=True)