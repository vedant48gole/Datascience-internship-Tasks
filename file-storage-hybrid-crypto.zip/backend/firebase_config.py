import firebase_admin
from firebase_admin import credentials, storage

cred = credentials.Certificate("serviceAccountKey.json")
firebase_admin.initialize_app(cred, {
    'storageBucket': '<your-bucket-name>.appspot.com'
})

def upload_to_firebase(filename, data):
    bucket = storage.bucket()
    blob = bucket.blob(filename)
    blob.upload_from_string(data)